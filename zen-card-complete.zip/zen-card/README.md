# Zen Card

A modern Next.js ecommerce starter with a server-side Razorpay Orders flow and payment-signature verification.

## Included

- Responsive ecommerce storefront
- Search and category filtering
- Cart with quantity controls
- Server-authoritative product prices
- Razorpay order creation on the server
- Razorpay Checkout.js on the client
- HMAC-SHA256 payment signature verification
- Vercel-ready Next.js App Router structure

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Razorpay setup

Create Razorpay API keys in your Razorpay Dashboard and put them in `.env.local`:

```env
RAZORPAY_KEY_ID=rzp_test_xxxxx
RAZORPAY_KEY_SECRET=xxxxx
NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_test_xxxxx
```

Never commit `RAZORPAY_KEY_SECRET`.

For initial testing, use Razorpay test/sandbox credentials. Before production, switch to your live credentials and complete the required Razorpay merchant onboarding/configuration.

## Deploy to Vercel

Import this GitHub repository into Vercel and add these environment variables:

- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `NEXT_PUBLIC_RAZORPAY_KEY_ID`

Then deploy.

## Payment architecture

1. Browser sends product IDs and quantities to `/api/create-order`.
2. Server resolves prices from `lib/products.js`.
3. Server creates a Razorpay order using the secret key.
4. Browser opens Razorpay Checkout using the public key and returned order ID.
5. Razorpay returns payment details to the browser.
6. Server verifies the signature at `/api/verify-payment`.

For a production store, add persistent order storage/database, idempotency, webhook handling, stock management, shipping/tax logic and an admin order workflow before accepting real orders.

import { NextResponse } from "next/server";
import { PRODUCTS } from "../../../lib/products";

export async function POST(request) {
  try {
    const body = await request.json();
    const items = Array.isArray(body.items) ? body.items : [];

    if (!items.length) {
      return NextResponse.json({ error: "Cart is empty." }, { status: 400 });
    }

    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      return NextResponse.json(
        { error: "Razorpay is not configured. Add the server environment variables." },
        { status: 500 }
      );
    }

    // Prices are resolved from the server-side catalogue, not from the browser.
    const normalized = items.map((item) => {
      const product = PRODUCTS.find((p) => p.id === item.id);
      const quantity = Math.max(1, Math.min(20, Number(item.quantity) || 1));
      if (!product) throw new Error(`Invalid product: ${item.id}`);
      return { product, quantity };
    });

    const amount = normalized.reduce(
      (sum, item) => sum + item.product.price * item.quantity,
      0
    );

    if (amount <= 0) throw new Error("Invalid order amount.");

    const auth = Buffer.from(
      `${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`
    ).toString("base64");

    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${auth}`
      },
      body: JSON.stringify({
        amount: amount * 100,
        currency: "INR",
        receipt: `zen_${Date.now()}`,
        notes: {
          store: "Zen Card",
          item_count: String(normalized.reduce((n, i) => n + i.quantity, 0))
        }
      }),
      cache: "no-store"
    });

    const data = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        { error: data?.error?.description || "Razorpay order creation failed." },
        { status: 502 }
      );
    }

    return NextResponse.json({
      id: data.id,
      amount: data.amount,
      currency: data.currency,
      keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || process.env.RAZORPAY_KEY_ID
    });
  } catch (error) {
    return NextResponse.json(
      { error: error.message || "Unable to create order." },
      { status: 400 }
    );
  }
}
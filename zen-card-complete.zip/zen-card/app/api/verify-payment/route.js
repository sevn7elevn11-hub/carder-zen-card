import crypto from "crypto";
import { NextResponse } from "next/server";

export async function POST(request) {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    } = await request.json();

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return NextResponse.json(
        { verified: false, error: "Incomplete payment response." },
        { status: 400 }
      );
    }

    if (!process.env.RAZORPAY_KEY_SECRET) {
      return NextResponse.json(
        { verified: false, error: "Razorpay secret is not configured." },
        { status: 500 }
      );
    }

    const payload = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expected = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(payload)
      .digest("hex");

    const a = Buffer.from(expected, "utf8");
    const b = Buffer.from(razorpay_signature, "utf8");

    const verified = a.length === b.length && crypto.timingSafeEqual(a, b);

    return NextResponse.json({
      verified,
      paymentId: verified ? razorpay_payment_id : undefined,
      orderId: verified ? razorpay_order_id : undefined
    }, { status: verified ? 200 : 400 });
  } catch {
    return NextResponse.json(
      { verified: false, error: "Payment verification failed." },
      { status: 400 }
    );
  }
}
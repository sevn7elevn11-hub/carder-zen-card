import "./globals.css";

export const metadata = {
  title: "Zen Card — Premium Cards",
  description: "A modern ecommerce store powered by Razorpay."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
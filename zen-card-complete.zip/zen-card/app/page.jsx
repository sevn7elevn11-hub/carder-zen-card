"use client";

import { useMemo, useState } from "react";
import { PRODUCTS } from "../lib/products";

const money = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(n);

export default function Home() {
  const [cart, setCart] = useState([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [openCart, setOpenCart] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  const categories = ["All", ...new Set(PRODUCTS.map((p) => p.category))];

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    return PRODUCTS.filter((p) => {
      const matchesCategory = category === "All" || p.category === category;
      const matchesQuery =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [query, category]);

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const count = cart.reduce((sum, item) => sum + item.qty, 0);

  function add(product) {
    setCart((current) => {
      const found = current.find((x) => x.id === product.id);
      if (found) {
        return current.map((x) =>
          x.id === product.id ? { ...x, qty: x.qty + 1 } : x
        );
      }
      return [...current, { ...product, qty: 1 }];
    });
    setOpenCart(true);
  }

  function changeQty(id, delta) {
    setCart((current) =>
      current
        .map((x) => (x.id === id ? { ...x, qty: x.qty + delta } : x))
        .filter((x) => x.qty > 0)
    );
  }

  async function checkout() {
    if (!cart.length || busy) return;
    setBusy(true);
    setNotice("");

    try {
      const orderResponse = await fetch("/api/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cart.map((item) => ({ id: item.id, quantity: item.qty }))
        })
      });

      const order = await orderResponse.json();
      if (!orderResponse.ok) throw new Error(order.error || "Could not create order");

      const loadScript = () =>
        new Promise((resolve, reject) => {
          if (window.Razorpay) return resolve();
          const script = document.createElement("script");
          script.src = "https://checkout.razorpay.com/v1/checkout.js";
          script.onload = resolve;
          script.onerror = () => reject(new Error("Razorpay Checkout failed to load"));
          document.body.appendChild(script);
        });

      await loadScript();

      const razorpay = new window.Razorpay({
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        name: "Zen Card",
        description: "Zen Card purchase",
        order_id: order.id,
        theme: { color: "#151515" },
        prefill: order.prefill,
        handler: async (response) => {
          const verifyResponse = await fetch("/api/verify-payment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(response)
          });
          const result = await verifyResponse.json();

          if (!verifyResponse.ok || !result.verified) {
            setNotice("Payment verification failed. Please contact support.");
            return;
          }

          setCart([]);
          setOpenCart(false);
          setNotice(`Payment successful. Payment ID: ${response.razorpay_payment_id}`);
        },
        modal: {
          ondismiss: () => setNotice("Checkout closed. Your cart is still saved.")
        }
      });

      razorpay.on("payment.failed", (response) => {
        setNotice(response?.error?.description || "Payment failed. Please try again.");
      });

      razorpay.open();
    } catch (error) {
      setNotice(error.message || "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main>
      <header className="nav">
        <a className="brand" href="#">
          <span className="brandMark">Z</span>
          <span>ZEN CARD</span>
        </a>
        <div className="navRight">
          <a href="#shop">Shop</a>
          <a href="#story">Story</a>
          <button className="cartButton" onClick={() => setOpenCart(true)}>
            Cart <span>{count}</span>
          </button>
        </div>
      </header>

      <section className="hero">
        <div className="heroCopy">
          <p className="eyebrow">DESIGNED FOR EVERYDAY MOMENTS</p>
          <h1>Less noise.<br /><em>More you.</em></h1>
          <p className="heroText">
            Premium cards with a quiet, modern aesthetic. Choose your Zen and
            make every detail feel intentional.
          </p>
          <a className="primaryButton" href="#shop">Explore cards <span>↘</span></a>
        </div>
        <div className="heroCardWrap" aria-label="Zen Card preview">
          <div className="heroCard">
            <div className="cardTop"><span>ZEN</span><span>01</span></div>
            <div className="cardSymbol">Z</div>
            <div className="cardBottom"><span>ZEN CARD</span><span>2026</span></div>
          </div>
        </div>
      </section>

      <section className="ticker">
        <span>MINIMAL DESIGN</span><b>✦</b><span>PREMIUM FINISH</span><b>✦</b>
        <span>MADE FOR INDIA</span><b>✦</b><span>SECURE CHECKOUT</span>
      </section>

      <section id="shop" className="shop">
        <div className="sectionHead">
          <div>
            <p className="eyebrow">THE COLLECTION</p>
            <h2>Find your card.</h2>
          </div>
          <div className="searchBox">
            <span>⌕</span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search cards..."
            />
          </div>
        </div>

        <div className="filters">
          {categories.map((item) => (
            <button
              key={item}
              className={category === item ? "active" : ""}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>

        <div className="productGrid">
          {filtered.map((product) => (
            <article className="product" key={product.id}>
              <div className="productVisual">
                <span className="badge">{product.badge}</span>
                <div className="miniCard">
                  <span>{product.icon}</span>
                  <small>ZEN CARD</small>
                </div>
              </div>
              <div className="productInfo">
                <div>
                  <h3>{product.name}</h3>
                  <p>{product.description}</p>
                </div>
                <strong>{money(product.price)}</strong>
              </div>
              <button className="addButton" onClick={() => add(product)}>
                Add to cart <span>+</span>
              </button>
            </article>
          ))}
        </div>
      </section>

      <section id="story" className="story">
        <div>
          <p className="eyebrow">WHY ZEN</p>
          <h2>Thoughtful by<br />design.</h2>
        </div>
        <p>
          Zen Card keeps things simple: premium-looking products, transparent
          pricing and a checkout experience built around Razorpay. This starter
          store is ready for your branding, real product catalogue and
          production payment credentials.
        </p>
      </section>

      <footer>
        <span>© 2026 Zen Card</span>
        <span>Made with intention.</span>
      </footer>

      {openCart && (
        <div className="overlay" onClick={() => setOpenCart(false)}>
          <aside className="cart" onClick={(e) => e.stopPropagation()}>
            <div className="cartHead">
              <div><p className="eyebrow">YOUR BAG</p><h2>Cart</h2></div>
              <button className="close" onClick={() => setOpenCart(false)}>×</button>
            </div>

            {!cart.length ? (
              <div className="empty">
                <div className="emptyIcon">◇</div>
                <h3>Your cart is empty.</h3>
                <p>Add a Zen Card to get started.</p>
              </div>
            ) : (
              <>
                <div className="cartItems">
                  {cart.map((item) => (
                    <div className="cartItem" key={item.id}>
                      <div className="cartThumb">{item.icon}</div>
                      <div className="cartItemInfo">
                        <strong>{item.name}</strong>
                        <span>{money(item.price)}</span>
                        <div className="qty">
                          <button onClick={() => changeQty(item.id, -1)}>−</button>
                          <span>{item.qty}</span>
                          <button onClick={() => changeQty(item.id, 1)}>+</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="cartSummary">
                  <div><span>Subtotal</span><strong>{money(total)}</strong></div>
                  <small>Taxes/shipping can be added before production launch.</small>
                  <button className="checkout" onClick={checkout} disabled={busy}>
                    {busy ? "Preparing checkout..." : `Pay ${money(total)} with Razorpay`}
                  </button>
                  {notice && <p className="notice">{notice}</p>}
                </div>
              </>
            )}
          </aside>
        </div>
      )}

      {!openCart && notice && <div className="toast">{notice}</div>}
    </main>
  );
}